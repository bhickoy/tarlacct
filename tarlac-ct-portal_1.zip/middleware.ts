import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const role = (req.nextauth.token as any)?.role;
    const path = req.nextUrl.pathname;

    // Supervisors are strictly view-only (spec Section 10) — block any
    // mutating request under /supervisor at the middleware level, not just
    // by hiding UI controls.
    if (path.startsWith("/supervisor") && req.method !== "GET") {
      return new NextResponse("Supervisors have read-only access.", { status: 403 });
    }

    if (path.startsWith("/admin") && role !== "admin") {
      return NextResponse.redirect(new URL("/login", req.url));
    }
    if (path.startsWith("/supervisor") && role !== "supervisor") {
      return NextResponse.redirect(new URL("/login", req.url));
    }
    if (path.startsWith("/school") && role !== "school") {
      return NextResponse.redirect(new URL("/login", req.url));
    }
    return NextResponse.next();
  },
  { callbacks: { authorized: ({ token }) => Boolean(token) } }
);

export const config = {
  matcher: ["/admin/:path*", "/supervisor/:path*", "/school/:path*"],
};
