import Image from "next/image";
import Link from "next/link";

export default function TopNav({
  title,
  links,
}: {
  title: string;
  links?: { href: string; label: string }[];
}) {
  return (
    <header className="bg-primary text-white">
      <div className="mx-auto max-w-6xl flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-full bg-white flex items-center justify-center border-2 border-accent overflow-hidden">
            <Image src="/logo.png" alt="TARLAC CT logo" width={36} height={36} />
          </div>
          <div>
            <p className="text-sm font-medium leading-tight">TARLAC CT PORTAL</p>
            <p className="text-xs text-accent leading-tight">{title}</p>
          </div>
        </div>
        <nav className="flex items-center gap-4">
          {links?.map((l) => (
            <Link key={l.href} href={l.href} className="text-sm text-white/90 hover:text-accent">
              {l.label}
            </Link>
          ))}
          <Link
            href="/api/auth/signout"
            className="text-sm px-3 py-1.5 rounded bg-secondary hover:bg-secondary-700"
          >
            Log out
          </Link>
        </nav>
      </div>
    </header>
  );
}
