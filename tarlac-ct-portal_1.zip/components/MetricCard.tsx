export default function MetricCard({
  label,
  value,
  dark = false,
}: {
  label: string;
  value: string | number;
  dark?: boolean;
}) {
  return (
    <div
      className={
        dark
          ? "bg-primary rounded-lg p-4"
          : "bg-primary-50 rounded-lg p-4 border-t-4 border-secondary"
      }
    >
      <p className={dark ? "text-xs text-accent mb-1" : "text-xs text-primary-600 mb-1"}>{label}</p>
      <p className={dark ? "text-xl font-medium text-white" : "text-xl font-medium text-primary"}>{value}</p>
    </div>
  );
}
