# TARLAC CT Portal

A working Next.js app built against the TARLAC CT build spec. Runs immediately
on realistic mock data — becomes live the moment you connect real Google
credentials.

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000. Log in with any of the demo accounts shown on the
login page (password for all three: `demo1234`).

## What's real vs. mocked right now

**Fully real and working:**
- Next.js App Router structure, TypeScript, Tailwind with your actual brand
  colors (navy `#122C4D`, teal `#1B8C86`, green `#8DC63F`) and logo
- NextAuth login with bcrypt password hashing and role-based middleware
  (admin / supervisor / school routes are genuinely protected — try visiting
  `/admin` while logged in as the school account)
- Supervisor role is enforced read-only at the middleware level, not just
  hidden in the UI
- Landing page, all three role dashboards, school profile edit, school
  results submission form, admin schools/districts/cycles/reports pages

**Mocked, with a clear swap-in point:**
- `lib/sheets.ts` is the single data-access layer the whole app calls. Every
  function has a `REAL INTEGRATION POINT` comment showing exactly where the
  live Google Sheets/Drive API call goes. Until the env vars below are set,
  every function returns realistic sample data (matching the real numbers
  from your dashboard screenshots and the 13 uploaded source files).
- The 13 legacy source spreadsheets (School Profile, Performance Indicators,
  National/Quarterly/RMYA Assessments, Project SOS, Trainings) aren't wired
  up individually yet — `lib/sheets.ts` has the pattern and one worked
  example (`getPerformanceIndicators` / `submitPerformanceIndicators`); the
  remaining 12 follow the same shape once you're ready to build them out,
  reading exact column headers from your original uploaded files.

## Going live

1. Follow spec Section 4 to create the Google Cloud service account and
   share the Drive folder with it.
2. Create a **new, separate spreadsheet** for `Users` / `Districts` /
   `Schools` / `AssessmentCycles` (this doesn't exist yet — see spec
   Section 5, points 3–4).
3. Copy `.env.example` to `.env.local` and fill in the four Google values
   plus a `NEXTAUTH_SECRET`.
4. Uncomment `getSheetsClient()` at the bottom of `lib/sheets.ts` and fill in
   the `REAL INTEGRATION POINT` blocks — start with `getDistricts` and
   `getSchools`, since everything else depends on those.
5. Replace the demo `MOCK_USERS` array with real Admin-provisioned accounts
   once the `Users` tab is live.

## What's not built yet (next steps)

- The other 12 legacy-source submission forms (National Assessment,
  Quarterly Assessment per grade, RMYA, Project SOS, Trainings) — the
  pattern is established, they're mechanical to add following the same
  shape as Performance Indicators.
- Admin create/edit/delete UI for schools, districts, and supervisors
  (currently read-only lists).
- CSV export on the admin reports page.
- The one-time import script that seeds `Schools` from the legacy
  `TCSD School Profile` responses (spec Section 5, point 5 — needs the
  name-normalization helper for inconsistent school name spelling).

See `TARLAC-CT-spec.md` for the full build spec this app was built against.
