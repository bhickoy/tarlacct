"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";

const DEMO_ACCOUNTS = [
  { role: "Admin", email: "admin@tarlacct.demo" },
  { role: "Supervisor", email: "supervisor@tarlacct.demo" },
  { role: "School", email: "school@tarlacct.demo" },
];

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await signIn("credentials", { email, password, redirect: false });
    if (res?.error) {
      setError("That email or password isn't right. Try again.");
      return;
    }
    if (email.includes("admin")) router.push("/admin");
    else if (email.includes("supervisor")) router.push("/supervisor");
    else router.push("/school");
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-primary-50 px-6">
      <div className="bg-white rounded-card border border-gray-200 p-8 w-full max-w-sm">
        <h1 className="text-lg font-medium text-primary mb-1">Log in</h1>
        <p className="text-sm text-primary-600 mb-6">TARLAC CT portal</p>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="email"
            placeholder="name@deped.gov.ph"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            required
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            className="w-full bg-secondary text-white rounded py-2 text-sm hover:bg-secondary-700"
          >
            Log in
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-gray-200">
          <p className="text-xs text-primary-600 mb-2">Demo accounts (password: demo1234)</p>
          {DEMO_ACCOUNTS.map((a) => (
            <button
              key={a.email}
              onClick={() => {
                setEmail(a.email);
                setPassword("demo1234");
              }}
              className="block text-xs text-secondary hover:underline mb-1"
            >
              {a.role} — {a.email}
            </button>
          ))}
        </div>
      </div>
    </main>
  );
}
