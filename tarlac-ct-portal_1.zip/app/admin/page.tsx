import { getSchools, getDistricts } from "@/lib/sheets";
import TopNav from "@/components/TopNav";
import MetricCard from "@/components/MetricCard";

export default async function AdminDashboard() {
  const [schools, districts] = await Promise.all([getSchools(), getDistricts()]);

  return (
    <main>
      <TopNav
        title="Admin"
        links={[
          { href: "/admin", label: "Dashboard" },
          { href: "/admin/schools", label: "Schools" },
          { href: "/admin/districts", label: "Districts" },
          { href: "/admin/cycles", label: "Cycles" },
          { href: "/admin/reports", label: "Reports" },
        ]}
      />
      <section className="mx-auto max-w-4xl px-6 py-8">
        <div className="grid grid-cols-3 gap-3 mb-6">
          <MetricCard label="Total schools" value={schools.length} />
          <MetricCard label="Districts" value={districts.length} />
          <MetricCard label="Overall MPS" value="67.49" />
        </div>
        <div className="bg-white border border-gray-200 rounded-card p-4">
          <p className="text-sm font-medium text-primary mb-2">Districts</p>
          <ul className="text-sm text-primary-600 grid grid-cols-2 gap-1">
            {districts.map((d) => (
              <li key={d.districtId}>{d.districtName}</li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}
