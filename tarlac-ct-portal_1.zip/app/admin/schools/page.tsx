import { getSchools, getDistricts } from "@/lib/sheets";
import TopNav from "@/components/TopNav";

export default async function AdminSchoolsPage() {
  const [schools, districts] = await Promise.all([getSchools(), getDistricts()]);
  const districtName = (id: string) => districts.find((d) => d.districtId === id)?.districtName ?? id;

  return (
    <main>
      <TopNav title="Schools" links={[{ href: "/admin", label: "Dashboard" }]} />
      <section className="mx-auto max-w-4xl px-6 py-8">
        <div className="bg-white border border-gray-200 rounded-card overflow-hidden">
          <div className="grid grid-cols-3 px-4 py-2 text-xs text-primary-600 bg-primary-50">
            <span>School</span>
            <span>District</span>
            <span>Enrollment</span>
          </div>
          {schools.map((s) => (
            <div key={s.schoolId} className="grid grid-cols-3 px-4 py-2 text-sm border-t border-gray-200">
              <span>{s.schoolName}</span>
              <span>{districtName(s.districtId)}</span>
              <span>{s.enrollment}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-primary-600 mt-3">
          Full create/edit/delete and password-reset controls go here once the portal spreadsheet
          (GOOGLE_PORTAL_SHEET_ID) is connected — this view reads live from the same lib/sheets.ts functions.
        </p>
      </section>
    </main>
  );
}
