import { getDistricts } from "@/lib/sheets";
import TopNav from "@/components/TopNav";

export default async function AdminDistrictsPage() {
  const districts = await getDistricts();
  return (
    <main>
      <TopNav title="Districts" links={[{ href: "/admin", label: "Dashboard" }]} />
      <section className="mx-auto max-w-2xl px-6 py-8">
        <div className="bg-white border border-gray-200 rounded-card p-4">
          <ul className="text-sm text-primary-600 space-y-1">
            {districts.map((d) => (
              <li key={d.districtId}>{d.districtName}</li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-primary-600 mt-3">
          Confirm this list against the division before launch — spec Section 14, open question 1.
        </p>
      </section>
    </main>
  );
}
