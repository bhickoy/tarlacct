import TopNav from "@/components/TopNav";

export default function AdminReportsPage() {
  return (
    <main>
      <TopNav title="Reports" links={[{ href: "/admin", label: "Dashboard" }]} />
      <section className="mx-auto max-w-2xl px-6 py-8">
        <div className="bg-white border border-gray-200 rounded-card p-4">
          <p className="text-sm font-medium text-primary mb-2">Legacy Looker Studio report</p>
          <p className="text-sm text-primary-600 mb-3">
            The 13 original data sources still feed this report — it keeps working unchanged.
          </p>
          <a
            href="https://datastudio.google.com/u/0/reporting/08ae0826-54b1-4482-816a-d69332577b57/page/xCLfF"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-secondary hover:underline"
          >
            Open Looker Studio report
          </a>
        </div>
      </section>
    </main>
  );
}
