import { getAssessmentCycles } from "@/lib/sheets";
import TopNav from "@/components/TopNav";

export default async function AdminCyclesPage() {
  const cycles = await getAssessmentCycles();
  return (
    <main>
      <TopNav title="Assessment cycles" links={[{ href: "/admin", label: "Dashboard" }]} />
      <section className="mx-auto max-w-2xl px-6 py-8">
        <div className="bg-white border border-gray-200 rounded-card overflow-hidden">
          {cycles.map((c) => (
            <div key={c.cycleId} className="flex items-center justify-between px-4 py-3 border-t border-gray-200 first:border-t-0">
              <span className="text-sm">{c.cycleName}</span>
              <span
                className={
                  c.status === "open"
                    ? "text-xs px-2 py-1 rounded bg-accent-50 text-accent-700"
                    : "text-xs px-2 py-1 rounded bg-gray-100 text-primary-600"
                }
              >
                {c.status}
              </span>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
