import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getSchools, getDistricts } from "@/lib/sheets";
import TopNav from "@/components/TopNav";
import MetricCard from "@/components/MetricCard";
import Link from "next/link";

export default async function SupervisorDashboard() {
  const session = await getServerSession(authOptions);
  const districtIds: string[] = (session?.user as any)?.districtIds ?? [];
  const districts = await getDistricts();
  const myDistricts = districts.filter((d) => districtIds.includes(d.districtId));
  const schools = (
    await Promise.all(districtIds.map((id) => getSchools(id)))
  ).flat();

  return (
    <main>
      <TopNav
        title={`District: ${myDistricts.map((d) => d.districtName).join(", ")} — view only`}
        links={[{ href: "/supervisor/schools", label: "Schools" }]}
      />
      <section className="mx-auto max-w-4xl px-6 py-8">
        <div className="grid grid-cols-3 gap-3 mb-6">
          <MetricCard label="Schools" value={schools.length} />
          <MetricCard label="Submitted" value="76%" />
          <MetricCard label="Pending" value="24%" />
        </div>
        <div className="bg-white border border-gray-200 rounded-card overflow-hidden">
          <div className="grid grid-cols-3 px-4 py-2 text-xs text-primary-600 bg-primary-50">
            <span>School</span>
            <span>Enrollment</span>
            <span>Status</span>
          </div>
          {schools.map((s) => (
            <Link
              key={s.schoolId}
              href={`/supervisor/schools/${s.schoolId}`}
              className="grid grid-cols-3 px-4 py-2 text-sm border-t border-gray-200 hover:bg-primary-50"
            >
              <span>{s.schoolName}</span>
              <span>{s.enrollment ?? "—"}</span>
              <span className="text-green-700">Submitted</span>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
