import { getSchoolById, getPerformanceIndicators } from "@/lib/sheets";
import TopNav from "@/components/TopNav";

export default async function SupervisorSchoolDetail({
  params,
}: {
  params: { schoolId: string };
}) {
  const [school, indicators] = await Promise.all([
    getSchoolById(params.schoolId),
    getPerformanceIndicators(params.schoolId),
  ]);
  const latest = indicators[indicators.length - 1];

  return (
    <main>
      <TopNav title={`${school?.schoolName ?? "School"} — view only`} links={[{ href: "/supervisor", label: "Back" }]} />
      <section className="mx-auto max-w-2xl px-6 py-8">
        <div className="bg-white border border-gray-200 rounded-card p-4">
          <p className="text-sm font-medium text-primary mb-2">Profile</p>
          <ul className="text-sm text-primary-600 space-y-1 mb-4">
            <li>School head: {school?.schoolHeadName} ({school?.schoolHeadPosition})</li>
            <li>Enrollment: {school?.enrollment}</li>
            <li>Teaching staff: {school?.teachingPersonnel}</li>
          </ul>
          <p className="text-sm font-medium text-primary mb-2">Latest performance</p>
          {latest ? (
            <ul className="text-sm text-primary-600 space-y-1">
              <li>Retention rate: {latest.retentionRate}%</li>
              <li>Dropout rate: {latest.dropoutRate}%</li>
              <li>Transition rate: {latest.transitionRate}%</li>
            </ul>
          ) : (
            <p className="text-sm text-primary-600">No submissions yet.</p>
          )}
        </div>
      </section>
    </main>
  );
}
