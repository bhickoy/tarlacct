import Link from "next/link";
import TopNav from "@/components/TopNav";
import MetricCard from "@/components/MetricCard";
import { getSchools, getDistricts } from "@/lib/sheets";

export default async function LandingPage() {
  const [schools, districts] = await Promise.all([getSchools(), getDistricts()]);

  return (
    <main>
      <TopNav title="Curriculum Implementation Division" />
      <section className="mx-auto max-w-3xl px-6 py-16 text-center">
        <h1 className="text-2xl font-medium text-primary mb-2">
          Tracking and Automation of Records
        </h1>
        <p className="text-sm text-primary-600 mb-8">
          for Learning, Assessment and Content: Curriculum on Technology
        </p>
        <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto mb-8">
          <MetricCard label="Schools" value={schools.length} />
          <MetricCard label="Districts" value={districts.length} />
          <MetricCard label="Submitted" value="76%" />
        </div>
        <Link
          href="/login"
          className="inline-block bg-secondary text-white px-6 py-2.5 rounded text-sm hover:bg-secondary-700"
        >
          Go to portal
        </Link>
      </section>
    </main>
  );
}
