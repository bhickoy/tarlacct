import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getPerformanceIndicators } from "@/lib/sheets";
import TopNav from "@/components/TopNav";

export default async function ResultsPage() {
  const session = await getServerSession(authOptions);
  const schoolId = (session?.user as any)?.schoolId ?? "s1";
  const indicators = await getPerformanceIndicators(schoolId);

  return (
    <main>
      <TopNav title="Historical results" links={[{ href: "/school", label: "Dashboard" }]} />
      <section className="mx-auto max-w-3xl px-6 py-8">
        {indicators.length === 0 ? (
          <p className="text-sm text-primary-600">No results submitted yet.</p>
        ) : (
          <table className="w-full text-sm border border-gray-200 rounded-card overflow-hidden">
            <thead className="bg-primary-50 text-primary-600 text-left">
              <tr>
                <th className="px-3 py-2">School year</th>
                <th className="px-3 py-2">Retention</th>
                <th className="px-3 py-2">Dropout</th>
                <th className="px-3 py-2">Transition</th>
              </tr>
            </thead>
            <tbody>
              {indicators.map((row, i) => (
                <tr key={i} className="border-t border-gray-200">
                  <td className="px-3 py-2">{row.schoolYear}</td>
                  <td className="px-3 py-2">{row.retentionRate}%</td>
                  <td className="px-3 py-2">{row.dropoutRate}%</td>
                  <td className="px-3 py-2">{row.transitionRate}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </main>
  );
}
