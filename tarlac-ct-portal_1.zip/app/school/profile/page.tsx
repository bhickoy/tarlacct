import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getSchoolById, upsertSchool, School } from "@/lib/sheets";
import TopNav from "@/components/TopNav";
import { revalidatePath } from "next/cache";

async function saveProfile(formData: FormData) {
  "use server";
  const schoolId = String(formData.get("schoolId"));
  const existing = await getSchoolById(schoolId);
  const updated: School = {
    ...(existing as School),
    schoolId,
    schoolName: String(formData.get("schoolName")),
    schoolHeadName: String(formData.get("schoolHeadName")),
    schoolHeadPosition: String(formData.get("schoolHeadPosition")),
    enrollment: Number(formData.get("enrollment")),
  };
  await upsertSchool(updated);
  revalidatePath("/school/profile");
}

export default async function SchoolProfilePage() {
  const session = await getServerSession(authOptions);
  const schoolId = (session?.user as any)?.schoolId ?? "s1";
  const school = await getSchoolById(schoolId);

  return (
    <main>
      <TopNav title="Edit profile" links={[{ href: "/school", label: "Dashboard" }]} />
      <section className="mx-auto max-w-lg px-6 py-8">
        <form action={saveProfile} className="space-y-4 bg-white border border-gray-200 rounded-card p-6">
          <input type="hidden" name="schoolId" value={schoolId} />
          <div>
            <label className="text-xs text-primary-600 block mb-1">School name</label>
            <input
              name="schoolName"
              defaultValue={school?.schoolName}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-primary-600 block mb-1">School head name</label>
            <input
              name="schoolHeadName"
              defaultValue={school?.schoolHeadName}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-primary-600 block mb-1">School head position</label>
            <input
              name="schoolHeadPosition"
              defaultValue={school?.schoolHeadPosition}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-primary-600 block mb-1">Enrollment</label>
            <input
              name="enrollment"
              type="number"
              defaultValue={school?.enrollment}
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          <button
            type="submit"
            className="bg-secondary text-white text-sm px-4 py-2 rounded hover:bg-secondary-700"
          >
            Save changes
          </button>
        </form>
      </section>
    </main>
  );
}
