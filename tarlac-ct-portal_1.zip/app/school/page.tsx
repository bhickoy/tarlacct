import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getSchoolById, getPerformanceIndicators, getAssessmentCycles } from "@/lib/sheets";
import TopNav from "@/components/TopNav";
import MetricCard from "@/components/MetricCard";
import Link from "next/link";

export default async function SchoolDashboard() {
  const session = await getServerSession(authOptions);
  const schoolId = (session?.user as any)?.schoolId ?? "s1";
  const [school, indicators, cycles] = await Promise.all([
    getSchoolById(schoolId),
    getPerformanceIndicators(schoolId),
    getAssessmentCycles(),
  ]);
  const openCycle = cycles.find((c) => c.status === "open");
  const latest = indicators[indicators.length - 1];

  return (
    <main>
      <TopNav
        title={school?.schoolName ?? "School"}
        links={[
          { href: "/school", label: "Dashboard" },
          { href: "/school/profile", label: "Profile" },
          { href: "/school/results", label: "Results" },
        ]}
      />
      <section className="mx-auto max-w-4xl px-6 py-8">
        <div className="grid grid-cols-3 gap-3 mb-6">
          <MetricCard label="Enrollment" value={school?.enrollment ?? "—"} dark />
          <MetricCard label="Teaching staff" value={school?.teachingPersonnel ?? "—"} dark />
          <MetricCard
            label="Retention rate"
            value={latest ? `${latest.retentionRate}%` : "—"}
            dark
          />
        </div>

        {openCycle && (
          <div className="bg-accent-50 border border-accent-100 rounded-card p-4 mb-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary">{openCycle.cycleName} is open</p>
              <p className="text-xs text-primary-600">Submit your results before it closes.</p>
            </div>
            <Link
              href="/school/submit"
              className="text-sm bg-secondary text-white px-4 py-2 rounded hover:bg-secondary-700"
            >
              Submit results
            </Link>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white border border-gray-200 rounded-card p-4">
            <p className="text-sm font-medium text-primary mb-2">Performance indicators</p>
            {latest ? (
              <ul className="text-sm text-primary-600 space-y-1">
                <li>Gross enrollment rate: {latest.grossEnrollmentRate}</li>
                <li>Cohort survival rate: {latest.cohortSurvivalRate}%</li>
                <li>Transition rate: {latest.transitionRate}%</li>
                <li>Dropout rate: {latest.dropoutRate}%</li>
              </ul>
            ) : (
              <p className="text-sm text-primary-600">No submissions yet.</p>
            )}
          </div>
          <div className="bg-white border border-gray-200 rounded-card p-4">
            <p className="text-sm font-medium text-primary mb-2">Facilities</p>
            <ul className="text-sm text-primary-600 space-y-1">
              <li>Instructional classrooms: {school?.instructionalClassrooms}</li>
              <li>Computer lab rooms: {school?.computerLabRooms}</li>
              <li>Functional computers: {school?.functionalComputers}</li>
              <li>Internet connectivity: {school?.internetConnectivity ? "Yes" : "No"}</li>
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}
