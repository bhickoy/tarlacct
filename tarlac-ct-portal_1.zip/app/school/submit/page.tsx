import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { submitPerformanceIndicators } from "@/lib/sheets";
import TopNav from "@/components/TopNav";
import { redirect } from "next/navigation";

async function submit(formData: FormData) {
  "use server";
  const schoolId = String(formData.get("schoolId"));
  await submitPerformanceIndicators({
    schoolId,
    schoolYear: String(formData.get("schoolYear")),
    grossEnrollmentRate: Number(formData.get("grossEnrollmentRate")),
    participationRate: Number(formData.get("participationRate")),
    cohortSurvivalRate: Number(formData.get("cohortSurvivalRate")),
    completionRate: Number(formData.get("completionRate")),
    dropoutRate: Number(formData.get("dropoutRate")),
    transitionRate: Number(formData.get("transitionRate")),
    retentionRate: Number(formData.get("retentionRate")),
  });
  redirect("/school");
}

const FIELDS = [
  ["grossEnrollmentRate", "Gross enrollment rate"],
  ["participationRate", "Participation rate"],
  ["cohortSurvivalRate", "Cohort survival rate"],
  ["completionRate", "Completion rate"],
  ["dropoutRate", "Dropout rate"],
  ["transitionRate", "Transition rate"],
  ["retentionRate", "Retention rate"],
] as const;

export default async function SubmitPage() {
  const session = await getServerSession(authOptions);
  const schoolId = (session?.user as any)?.schoolId ?? "s1";

  return (
    <main>
      <TopNav title="Submit results" links={[{ href: "/school", label: "Dashboard" }]} />
      <section className="mx-auto max-w-lg px-6 py-8">
        <p className="text-sm text-primary-600 mb-4">
          This mirrors the <code className="text-xs">TCSD School Performance Indicators</code> form —
          submitting here writes to that same spreadsheet once live credentials are connected.
        </p>
        <form action={submit} className="space-y-3 bg-white border border-gray-200 rounded-card p-6">
          <input type="hidden" name="schoolId" value={schoolId} />
          <div>
            <label className="text-xs text-primary-600 block mb-1">School year</label>
            <input
              name="schoolYear"
              defaultValue="SY 2025-2026"
              className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
            />
          </div>
          {FIELDS.map(([key, label]) => (
            <div key={key}>
              <label className="text-xs text-primary-600 block mb-1">{label}</label>
              <input
                name={key}
                type="number"
                step="0.01"
                className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
                required
              />
            </div>
          ))}
          <button
            type="submit"
            className="bg-secondary text-white text-sm px-4 py-2 rounded hover:bg-secondary-700"
          >
            Submit results
          </button>
        </form>
      </section>
    </main>
  );
}
