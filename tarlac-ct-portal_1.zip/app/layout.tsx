import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TARLAC CT Portal",
  description: "Tracking and Automation of Records for Learning, Assessment and Content: Curriculum on Technology",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-white text-primary-900 antialiased">{children}</body>
    </html>
  );
}
