# TARLAC CT Portal — Build Specification

> **Project:** TARLAC CT — Tracking & Automation of Records for Learning, Assessment & Content: Curriculum on Technology
> **Scope:** District → School reporting portal with role-based logins, data entry, and dashboards.
> **Purpose of this document:** Hand this file to Claude Code as the build spec. It describes what to build, in what order, and how the pieces fit together.

---

## 1. Background & Problem

Today, data collection runs entirely on a single shared Google Sheet:
- One link is shared with all schools to encode school data, assessment results, and other info whenever a submission is requested.
- Results sync into a Looker Studio (Google Data Studio) dashboard: https://datastudio.google.com/u/0/reporting/08ae0826-54b1-4482-816a-d69332577b57/page/xCLfF
- There is **no individual login per school** — anyone with the link can edit any school's row.
- There is **no per-school dashboard/landing page**.
- There is **no admin dashboard**.
- There is **no concept of a District Supervisor role** overseeing a set of schools.

## 2. Solution Overview

Build a single web portal with three role-based experiences:

| Role | Can do |
|---|---|
| **Admin** | Full access: manage schools, manage supervisors, manage assessment forms/cycles, view all data and dashboards, export reports, manage user accounts. |
| **Supervisor** (District) | **View-only** access to all schools within their assigned district(s) — school profiles, submissions, and aggregated dashboards for their district. Cannot edit school data or manage global settings. |
| **School** | Log in to their own school's account only; encode/update their own school profile (name, logo, school head name & position), submit assessment results and other requested info; view their own results with charts and interpretation. |

Data continues to live in **Google Sheets** (per your chosen stack), so existing historical data and the existing Data Studio report keep working. The portal reads/writes to Sheets via the Google Sheets API instead of schools editing the sheet directly, and also builds native in-portal dashboards so schools/supervisors/admins don't have to leave the portal to see results.

---

## 3. Tech Stack

- **Framework:** Next.js 14+ (App Router, TypeScript)
- **Styling/UI:** Tailwind CSS + shadcn/ui components
- **Auth:** NextAuth.js (Credentials provider) with per-account login (email/username + password), role stored on the session (`admin`, `supervisor`, `school`)
- **Data backend:** Google Sheets, accessed via a **Google Service Account** and the Sheets API v4 (`googleapis` npm package) — no schools ever touch the raw sheet directly again
- **Charts:** Recharts (native in-portal dashboards)
- **File storage (school logos):** Google Drive via the same service account, OR Vercel Blob storage (pick one — Drive keeps everything inside Google's ecosystem, Blob is simpler to wire up). **Default: Vercel Blob**, with a fallback note for Drive if the user wants everything inside Google's account.
- **Hosting:** Vercel
- **Reporting:** Keep the existing Looker Studio report connected directly to the Sheet (unchanged) as a backup/legacy view; the portal is the new primary way to view dashboards.

---

## 4. Google Cloud Service Account Setup (no existing account — do this first)

Claude Code should walk the user through this before writing any Sheets/Drive integration code, since no service account exists yet:

1. Go to console.cloud.google.com and create a new project (e.g., "tarlac-ct-portal").
2. Enable both the **Google Sheets API** and the **Google Drive API** for that project (Drive API is now required — the portal reads from and writes to multiple spreadsheets inside a shared Drive folder, not a single sheet).
3. Go to **IAM & Admin → Service Accounts → Create Service Account**, name it something like `tarlac-ct-sheets`.
4. Create a **JSON key** for that service account and download it — this file contains the credentials the app needs (`client_email` and `private_key`).
5. Share the **entire Drive folder** (drive.google.com/drive/folders/1w81YUSvGGlnpEAQMMONICpu7Gs9_Tqou — currently owned by maremalyne.cruz@deped.gov.ph) with the service account's `client_email`, with **Editor** access. Sharing the folder (rather than each of the 13 files individually) is what lets the service account read and write every current and future form response sheet inside it without a separate share step per file.
6. Store the values from the JSON key as environment variables (never commit the JSON file itself):
   - `GOOGLE_SHEETS_CLIENT_EMAIL`
   - `GOOGLE_SHEETS_PRIVATE_KEY` (keep the `\n` line breaks intact, or base64-encode it and decode at runtime)
   - `GOOGLE_DRIVE_FOLDER_ID` = `1w81YUSvGGlnpEAQMMONICpu7Gs9_Tqou`
7. Add the same env vars in Vercel's project settings when deploying, not just locally.

Claude Code should build the `lib/sheets.ts` setup script (step 2 of the Build Order below) so that on first run it verifies these env vars are present and gives a clear error message naming the missing one, rather than a raw API error.

## 5. Real Data Sources (confirmed via the connected Drive folder)

The Drive folder is **not** a single spreadsheet with tabs — it's a set of **13 separate Google Forms, each backing its own response spreadsheet** (26 files total: 13 forms + 13 "(Responses)" spreadsheets), all owned by the division's account. This was confirmed directly against the live folder, not assumed. The Looker Studio report reads from these spreadsheets. The 13 sources:

| # | Source name | Captures |
|---|---|---|
| 1 | `TCSD School Profile` | Enrollment, teacher/non-teaching counts, classroom/lab/clinic/canteen counts, internet and water supply flags — one row per school per school year |
| 2 | `TCSD School Performance Indicators` | Gross Enrollment Rate, Participation Rate, Cohort Survival Rate, Completion Rate, Dropout Rate, Transition Rate, Retention Rate — one row per school per school year |
| 3 | `TCSD National Assessment Results (Elem)` | Assessment Program (e.g. NAT G6, ELLNA), School Year, District, School, MPS — one row per school per program |
| 4 | `TCSD National Assessment Results (JHS)` | Same shape as #3, for NAT G10 |
| 5 | `TCSD Quarterly Assessment Result (Elem)` | Per grade (1–6), per subject: male/female test takers, number exceeding MPL, and MPS — very wide, one row per school per quarter |
| 6 | `TCSD Quarterly Assessment Result (JHS)` | Same pattern as #5, for grades 7–10, JHS subject set (English, Filipino, Science, Math, TLE, MAPEH, AP, Values Ed) |
| 7 | `TCSD Quarterly Assessment Result (SHS)` | Same pattern, for grades 11–12, SHS core + specialized subjects (very wide — dozens of subject columns) |
| 8 | `TCSD RMYA MPL (Elem)` | Regional Mid-Year Assessment — per grade (K–6), total test takers, per-subject MPL and MPS |
| 9 | `TCSD RMYA MPL (JHS)` | Same pattern, grades 7–10 |
| 10 | `TCSD RMYA MPL (SHS)` | Same pattern, SHS subject list, with `N/A` used for not-offered subjects |
| 11 | `TCSD RMYA Most and Least Learned LCs` | Grade level, learning area, and the top-10 most-learned and least-learned competency item numbers — one row per school per grade per subject |
| 12 | `TCSD Project SOS` | Technical Assistance tracking: District, Quarter, Month, TA Provider, counts of Proficient/Highly Proficient teachers and school heads given TA |
| 13 | `TCSD-CID Trainings Conducted` | School Year, Learning Area, training title and date, counts of trained elementary/secondary teachers and school heads, training output |

> Full exact column lists (some sources have 100+ columns) are in the original uploaded files — Claude Code should read those directly when building each source's parser/writer rather than retyping headers from this summary, to guarantee an exact column match.

**What this means for the build — replacing the earlier single-sheet plan:**

1. **No unified `AssessmentResults` tab.** The earlier plan (one normalized long-format tab for all indicators) doesn't fit 13 independently-evolving wide-format sources with different columns per grade/subject. Instead, `lib/sheets.ts` gets **one typed reader/writer per source** (`getSchoolProfile()`, `submitQuarterlyAssessmentJHS()`, etc.), each writing directly into its matching real spreadsheet, in that spreadsheet's exact existing column order. This is what actually keeps Looker Studio in sync going forward — the portal becomes a friendlier front door onto the same 13 sheets, not a parallel system.
2. **The portal's submission forms are grouped to match these 13 sources**, not one generic "submit results" form. A school's `/school/submit/[cycleId]` flow should present these as separate sections/steps (School Profile, Performance Indicators, National Assessment, Quarterly Assessment by grade, RMYA, etc.) mirroring the existing Google Forms schools already fill out.
3. **`Users`, `Districts`, and `Schools` (for login + profile metadata like logo and school head) are genuinely new** — nothing in the 13 sources supports authentication or stores a school logo. These live in a **new, separate spreadsheet** created for the portal (not mixed into the legacy folder), since they have nothing to do with Looker Studio's existing data sources. Store its ID as a new `GOOGLE_PORTAL_SHEET_ID` env var alongside `GOOGLE_DRIVE_FOLDER_ID`.
4. **`AssessmentCycles`** (open/close windows for submissions) also lives in this new portal spreadsheet — none of the 13 legacy sources track submission windows, they're just running logs of form responses.
5. School identity/matching across all 13 sources relies on **School name + District**, spelled inconsistently in places (e.g., "Armenia Integrated School" vs "ARMENIA INTEGRATED SCHOOL", trailing spaces like "Ungot Integrated School "). Claude Code should build a shared **name-normalization helper** (trim, uppercase-compare) used everywhere school names are matched against the new `Schools` tab, and flag unmatched rows during the one-time import rather than silently dropping them.
6. **District list observed across sources** (for seeding the new `Districts` tab): Central A, Central B, East, North A, North B, South A, South B, West A, West B, West C — confirm this full list with the user before finalizing, since it's inferred from sampled data, not a definitive source.

## 6. Google Sheets Schema

### New portal spreadsheet (`GOOGLE_PORTAL_SHEET_ID`) — auth and metadata only

Claude Code should create a setup script that provisions these tabs/headers on first run if they don't exist:

#### `Users`
| Column | Notes |
|---|---|
| user_id | UUID |
| role | `admin` \| `supervisor` \| `school` |
| email | login identifier |
| password_hash | bcrypt |
| school_id | FK to `Schools`, blank for admin/supervisor |
| district_ids | comma-separated FK to `Districts`, used for supervisors |
| created_at | |

#### `Districts`
| district_id | district_name |
|---|---|
Seed with the observed list (Central A, Central B, East, North A, North B, South A, South B, West A, West B, West C) after confirming with the user — see Section 5, point 6.

#### `Schools`
| school_id | district_id | school_name | school_logo_url | school_head_name | school_head_position | address | contact_info | created_at | updated_at |
|---|---|---|---|---|---|---|---|---|---|
`school_name` should be normalized (trim, consistent casing) but store the canonical display form; the name-matching helper (Section 5, point 5) is what reconciles this against the varied spellings in the 13 legacy sources.

#### `AssessmentCycles`
Defines each open/close submission window admins control (e.g., "SY 2026-2027 Quarter 2"). This is new — none of the 13 legacy sources track a window, they're just running form logs.
| cycle_id | cycle_name | school_year | quarter (nullable) | open_date | close_date | status (`draft`/`open`/`closed`) | created_by |

#### `Announcements` (optional, for the admin → schools request flow)
| announcement_id | title | message | cycle_id (optional link) | posted_by | posted_at |

### The 13 legacy source spreadsheets — read/write targets, not redesigned

These are **not** rebuilt as a normalized schema. Each of the 13 sources in Section 5 keeps its own exact existing columns; `lib/sheets.ts` gets one typed function pair per source (e.g. `getSchoolPerformanceIndicators(schoolId, schoolYear)` / `submitSchoolPerformanceIndicators(data)`, `getQuarterlyAssessmentJHS(...)` / `submitQuarterlyAssessmentJHS(...)`), each reading/writing that specific spreadsheet by its real header row. Claude Code should read each of the 13 uploaded files directly to get the exact, complete column list before writing each function — the summaries in Section 5 are for orientation, not the literal header source.

> **Note for Claude Code:** build `lib/sheets.ts` so the rest of the app never calls the Sheets/Drive API directly — one client, typed functions per source plus the new portal tabs, so swapping any individual piece later doesn't ripple through the UI code.

---

## 7. Branding

The user has supplied their logo (a circular seal reading "TARLAC CT — Curriculum Implementation Division", with the tagline values Transparency, Integrity, Accountability). Claude Code should:

- Place the logo file at `/public/logo.png`.
- Set these brand colors as the Tailwind theme in `tailwind.config.ts` (approximated from the logo — user should fine-tune exact hex values against their official brand guide if one exists):
  - `primary` (navy): `#122C4D`
  - `secondary` (teal): `#1B8C86`
  - `accent` (green): `#8DC63F`
  - Neutral white/background stays the default light surface.
- Use the logo mark in the landing page header, the login page, and the nav/sidebar of all three portals; navy as the primary text/header color, teal as the primary button/link color, green as a secondary accent (badges, success states, highlight borders) — not all three competing on one element.
- Wire every screen through these Tailwind theme tokens, never hardcoded hex in components, so a future palette tweak is a one-file change.

## 8. Core Pages / Routes

The existing Looker Studio report (reviewed via screenshots) has four tabs, and the portal's dashboard pages should mirror this same structure so users find things where they expect: **School Profile**, **School Performance Indicators**, and **Assessment** (broken out by Elementary / JHS / SHS, each with a National Achievement Test panel and a Regional/Quarterly Assessment panel with District/School/Year/Quarter filters, MPS gauges, proficiency-band counts, and a per-school results table).

### Public
- `/` — Landing page: TARLAC CT branding, division-wide highlights (aggregate enrollment, schools reporting, overall MPS), login button.
- `/login` — Single login page; redirects by role after auth (`/admin`, `/supervisor`, `/school`).

### School portal (`/school/*`)
- `/school` — Dashboard: this school's profile (enrollment, personnel, facility counts), latest performance indicators, and assessment MPS by grade level, charts + interpretation blurbs, open assessment cycles awaiting submission.
- `/school/profile` — Edit school name, logo, school head name & position, contact info, and the profile/facility fields listed in Section 6 (enrollment, personnel, classrooms, labs, connectivity, etc.).
- `/school/submit/[cycleId]` — Form to submit/update performance and assessment indicators for an open cycle.
- `/school/results` — Historical results with charts/filters by cycle, matching the National Achievement Test / Regional / Quarterly breakdown schools are used to seeing.

### Supervisor portal (`/supervisor/*`)
- `/supervisor` — Dashboard aggregating all schools in their district(s): completion rates, summary charts.
- `/supervisor/schools` — List of schools in their district(s) with submission status (submitted/pending) per open cycle.
- `/supervisor/schools/[schoolId]` — Drill into one school's profile + results (**read-only view** — no edit controls rendered for this role).

### Admin portal (`/admin/*`)
- `/admin` — Global dashboard: totals, completion rates by district, flagged/late schools.
- `/admin/schools` — CRUD schools, assign district, reset school password.
- `/admin/districts` — CRUD districts.
- `/admin/supervisors` — CRUD supervisor accounts, assign districts to supervisors.
- `/admin/cycles` — Create/open/close assessment cycles (indicators are fixed and shared across all cycles — no per-cycle indicator editor).
- `/admin/announcements` — Post requests/announcements schools see on login.
- `/admin/reports` — Cross-district charts/exports (CSV export button), link out to the legacy Looker Studio report.

---

## 9. Dashboards & Data Interpretation

For each results view (school/supervisor/admin, scoped appropriately), build:
- The same **District / School / School Year / Quarter filter bar** the existing dashboard uses (Reset filters button included), scoped to what each role is allowed to see — school sees no district/school filter (locked to itself), supervisor's district filter is locked to their assigned district(s), admin has full filters.
- Summary/gauge cards matching the existing report's pattern: Total Test Takers, Overall MPS, and proficiency-band counts (Highly Proficient / Proficient / Nearly Proficient / Low Proficient / Not Proficient), plus a "Schools submitted" gauge.
- At least 2 chart types (bar for comparison across indicators/schools, line/trend for cycle-over-cycle change, matching the Performance Indicators tab's line-chart style).
- A short auto-generated plain-language interpretation line under each chart (e.g., "Completion rate rose 12% from the last cycle" / "3 of 10 indicators are below target") — simple rule-based text, not AI-generated, so it's predictable and free to run.

---

## 10. Auth & Access Rules

- Passwords hashed with bcrypt, stored in the `Users` tab.
- Session (NextAuth JWT) carries `role`, `school_id` (if school), `district_ids` (if supervisor).
- Middleware enforces: `school` role can only read/write rows where `school_id` matches their own; `supervisor` role is **strictly read-only** and can only read rows where `district_id` is in their assigned districts (no write endpoints are exposed to this role at all, not just hidden in the UI); `admin` has no restriction.
- Admin can reset any password and create new School/Supervisor accounts (self-signup is **not** in scope — accounts are provisioned by Admin).

---

## 11. Build Order (phases for Claude Code to follow)

1. **Scaffold**: Next.js + Tailwind + shadcn/ui project, env vars for Google service account, Drive folder ID, and new portal Sheet ID.
2. **Sheets/Drive data layer**: `lib/sheets.ts` with a typed function pair per legacy source (Section 6) plus the new portal tabs, and a setup script that creates the new portal spreadsheet's tabs/headers if they don't exist. Read each of the 13 uploaded source files directly for exact column lists while building this.
3. **Auth**: NextAuth credentials provider reading from `Users` tab, role-based middleware/route protection.
4. **Admin: Schools/Districts/Supervisors CRUD** (needed before anything else can be tested end-to-end). Seed `Schools` via the one-time import described in Section 5.
5. **School: profile edit + logo upload**, writing into both the new `Schools` tab and the legacy `TCSD School Profile` response sheet.
6. **Admin: Assessment cycles CRUD.**
7. **School: submission flow**, built as sections matching the 13 legacy sources (Performance Indicators, National Assessment, Quarterly Assessment per grade, RMYA, etc.) rather than one generic form — each section writes to its matching legacy spreadsheet.
8. **Dashboards**: school → supervisor → admin, in that order, reusing one chart/filter-bar component set (Section 9).
9. **Landing page** (can be last — it's mostly static + aggregate stats pulled from the same data layer).
10. **Polish**: announcements, CSV export, link to legacy Looker Studio report from admin/reports.
11. **Launch cutover**: once the portal's submission flow is verified against all 13 sources, close/unpublish the 13 original Google Forms so schools submit only through the portal going forward — the response spreadsheets keep receiving data either way, just from one entry point instead of two.

---

## 12. Non-Functional Requirements

- Scale target: **50–300 schools**, a handful of admins/supervisors — this is well within Google Sheets/Drive API rate limits as long as reads are cached (use Next.js caching / revalidate on a short interval, e.g., 60s, rather than hitting the API on every request).
- Mobile-friendly (many school users will be on phones/tablets).
- All write actions (submit results, edit profile) show clear success/error confirmation.

---

## 13. Assumptions (flag to the user if wrong)

- The Drive folder (drive.google.com/drive/folders/1w81YUSvGGlnpEAQMMONICpu7Gs9_Tqou) holds **13 separate Google Forms and their response spreadsheets** — confirmed directly against the live folder, not assumed. See Section 5 for the full inventory.
- The portal keeps writing directly into each of these 13 spreadsheets, in their existing exact column format, so the Looker Studio report stays live and synced going forward — there's no unified results tab standing in between.
- **`Users`, `Districts`, `Schools`, and `AssessmentCycles` are new** and live in a separate portal spreadsheet, since none of the 13 legacy sources support login, school metadata (logo, school head), or submission windows.
- No Google Cloud service account exists yet — Claude Code sets one up from scratch per Section 4, sharing the **whole Drive folder** (not each file individually) so future sources added to the folder are automatically covered.
- Supervisors are **strictly view-only** — no write access or edit UI anywhere in their portal.
- Accounts are Admin-provisioned, not self-service signup.
- One school = one login account (not multiple staff logins per school) — flag if multiple logins per school are actually needed.
- Logo storage defaults to Vercel Blob rather than Google Drive, for simplicity.
- Brand colors are approximated from the supplied logo (Section 7) — treat as a starting palette, confirm exact hex values against an official brand guide if one exists.
- The district list (Section 5, point 6) is inferred from sampled response data across the 13 sources, not a definitive source — confirm the full list before seeding `Districts`.
- School names are spelled inconsistently across the 13 sources (casing, trailing spaces, abbreviation) — the name-normalization helper (Section 5, point 5) handles matching, but genuinely ambiguous matches should be surfaced for a human to resolve during import, not silently guessed.
- The 13 existing Google Forms are **fully replaced at launch** — once the portal's submission flow goes live, schools use it instead of the old forms. The forms should be closed/unpublished (stop accepting new responses) as part of launch, since two active entry points into the same spreadsheets would risk duplicate or conflicting rows. The response spreadsheets themselves stay as the write target either way (Section 5).

---

## 14. Open Questions for the User (still open — answer whenever ready, doesn't have to block the start of the build)

1. Is the district list observed in the data (Central A, Central B, East, North A, North B, South A, South B, West A, West B, West C) complete, or are there others not represented in the sampled rows?

