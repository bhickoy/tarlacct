import type { Config } from "tailwindcss";

// Brand colors pulled from the TARLAC CT seal (Curriculum Implementation Division).
// Fine-tune against an official brand guide if one exists — see README.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#122C4D", // navy — header/text
          50: "#EAF0F7",
          100: "#C7D6E8",
          600: "#1A3A63",
          900: "#122C4D",
        },
        secondary: {
          DEFAULT: "#1B8C86", // teal — buttons/links
          50: "#E6F5F4",
          100: "#BFE6E3",
          600: "#1B8C86",
          700: "#146E69",
        },
        accent: {
          DEFAULT: "#8DC63F", // green — badges/highlights
          50: "#F1F8E5",
          100: "#DCEFB8",
          600: "#8DC63F",
          700: "#71A22F",
        },
      },
      borderRadius: {
        card: "12px",
      },
    },
  },
  plugins: [],
};
export default config;
