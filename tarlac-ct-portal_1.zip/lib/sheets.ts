// lib/sheets.ts
//
// Single data-access layer. The rest of the app calls ONLY the functions
// below — never the Sheets/Drive API directly. That's what makes swapping
// mock data for live data a one-file change.
//
// LIVE MODE: set GOOGLE_SHEETS_CLIENT_EMAIL, GOOGLE_SHEETS_PRIVATE_KEY,
// GOOGLE_DRIVE_FOLDER_ID, and GOOGLE_PORTAL_SHEET_ID (see README.md /
// spec Section 4) and this file talks to the real Google Sheets API.
//
// MOCK MODE (default, no env vars set): every function below returns
// realistic sample data so the whole app runs and demos immediately.
// Look for "REAL INTEGRATION POINT" comments — that's exactly where the
// googleapis calls go once credentials exist.

export type Role = "admin" | "supervisor" | "school";

export interface User {
  userId: string;
  role: Role;
  email: string;
  passwordHash: string;
  schoolId?: string;
  districtIds?: string[];
}

export interface District {
  districtId: string;
  districtName: string;
}

export interface School {
  schoolId: string;
  districtId: string;
  schoolName: string;
  schoolLogoUrl?: string;
  schoolHeadName?: string;
  schoolHeadPosition?: string;
  enrollment?: number;
  teachingPersonnel?: number;
  nonTeachingPersonnel?: number;
  instructionalClassrooms?: number;
  facultyRooms?: number;
  computerLabRooms?: number;
  scienceLabRooms?: number;
  clinic?: number;
  canteen?: number;
  functionalComputers?: number;
  internetConnectivity?: boolean;
  waterSupply?: number;
}

export interface PerformanceIndicators {
  schoolId: string;
  schoolYear: string;
  grossEnrollmentRate: number;
  participationRate: number;
  cohortSurvivalRate: number;
  completionRate: number;
  dropoutRate: number;
  transitionRate: number;
  retentionRate: number;
}

export interface AssessmentCycle {
  cycleId: string;
  cycleName: string;
  schoolYear: string;
  quarter?: string;
  status: "draft" | "open" | "closed";
}

const isLiveMode = () =>
  Boolean(
    process.env.GOOGLE_SHEETS_CLIENT_EMAIL &&
      process.env.GOOGLE_SHEETS_PRIVATE_KEY &&
      process.env.GOOGLE_DRIVE_FOLDER_ID &&
      process.env.GOOGLE_PORTAL_SHEET_ID
  );

// ---------------------------------------------------------------------------
// Districts observed across the 13 legacy sources — confirm the full list
// with the division before relying on this for anything beyond the demo
// (see spec Section 14, open question 1).
// ---------------------------------------------------------------------------
const MOCK_DISTRICTS: District[] = [
  "Central A", "Central B", "East", "North A", "North B",
  "South A", "South B", "West A", "West B", "West C",
].map((name, i) => ({ districtId: `d${i + 1}`, districtName: name }));

const MOCK_SCHOOLS: School[] = [
  {
    schoolId: "s1",
    districtId: "d8",
    schoolName: "Alvindia Aguso High School",
    schoolHeadName: "Maria Santos",
    schoolHeadPosition: "Principal IV",
    enrollment: 5105,
    teachingPersonnel: 118,
    nonTeachingPersonnel: 17,
    instructionalClassrooms: 86,
    facultyRooms: 12,
    computerLabRooms: 11,
    scienceLabRooms: 10,
    clinic: 10,
    canteen: 11,
    functionalComputers: 73,
    internetConnectivity: true,
    waterSupply: 4,
  },
  {
    schoolId: "s2",
    districtId: "d8",
    schoolName: "Ungot Integrated School",
    schoolHeadName: "Juan Dela Cruz",
    schoolHeadPosition: "School Head",
    enrollment: 1240,
    teachingPersonnel: 42,
    nonTeachingPersonnel: 6,
    instructionalClassrooms: 28,
    facultyRooms: 4,
    computerLabRooms: 2,
    scienceLabRooms: 1,
    clinic: 1,
    canteen: 1,
    functionalComputers: 18,
    internetConnectivity: true,
    waterSupply: 1,
  },
  {
    schoolId: "s3",
    districtId: "d9",
    schoolName: "Maliwalo National High School",
    schoolHeadName: "Ana Reyes",
    schoolHeadPosition: "Principal III",
    enrollment: 3210,
    teachingPersonnel: 88,
    nonTeachingPersonnel: 11,
    instructionalClassrooms: 54,
    facultyRooms: 8,
    computerLabRooms: 6,
    scienceLabRooms: 5,
    clinic: 1,
    canteen: 2,
    functionalComputers: 45,
    internetConnectivity: true,
    waterSupply: 2,
  },
];

const MOCK_PERFORMANCE: PerformanceIndicators[] = [
  {
    schoolId: "s1",
    schoolYear: "SY 2025-2026",
    grossEnrollmentRate: 98,
    participationRate: 95,
    cohortSurvivalRate: 89,
    completionRate: 92,
    dropoutRate: 0,
    transitionRate: 85,
    retentionRate: 90,
  },
];

const MOCK_CYCLES: AssessmentCycle[] = [
  { cycleId: "c1", cycleName: "SY 2025-2026 Quarter 3", schoolYear: "SY 2025-2026", quarter: "Q3", status: "open" },
  { cycleId: "c2", cycleName: "SY 2025-2026 Quarter 2", schoolYear: "SY 2025-2026", quarter: "Q2", status: "closed" },
];

// ---------------------------------------------------------------------------
// Public API — every function the app calls
// ---------------------------------------------------------------------------

export async function getDistricts(): Promise<District[]> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: read the `Districts` tab from the sheet at
    // GOOGLE_PORTAL_SHEET_ID via googleapis (see getSheetsClient() below).
  }
  return MOCK_DISTRICTS;
}

export async function getSchools(districtId?: string): Promise<School[]> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: read the `Schools` tab from GOOGLE_PORTAL_SHEET_ID.
  }
  return districtId ? MOCK_SCHOOLS.filter((s) => s.districtId === districtId) : MOCK_SCHOOLS;
}

export async function getSchoolById(schoolId: string): Promise<School | undefined> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: look up a single row in the `Schools` tab.
  }
  return MOCK_SCHOOLS.find((s) => s.schoolId === schoolId);
}

export async function upsertSchool(school: School): Promise<School> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: write/update the row in the `Schools` tab AND
    // append/update the matching row in the legacy `TCSD School Profile`
    // response spreadsheet (Drive folder), per spec Section 5 point 5 —
    // use the school-name normalization helper to match existing rows.
  }
  const idx = MOCK_SCHOOLS.findIndex((s) => s.schoolId === school.schoolId);
  if (idx >= 0) MOCK_SCHOOLS[idx] = school;
  else MOCK_SCHOOLS.push(school);
  return school;
}

export async function getPerformanceIndicators(schoolId: string): Promise<PerformanceIndicators[]> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: read from the legacy `TCSD School Performance
    // Indicators` response spreadsheet, filtered by school name/district.
  }
  return MOCK_PERFORMANCE.filter((p) => p.schoolId === schoolId);
}

export async function submitPerformanceIndicators(data: PerformanceIndicators): Promise<void> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: append a row to the legacy `TCSD School
    // Performance Indicators` response spreadsheet, matching its exact
    // existing column order (Timestamp, Email, District, School, School
    // Year, Gross Enrollment Rate, Participation Rate, Cohort Survival
    // Rate, Completion Rate, Dropout Rate, Transition Rate, Retention Rate).
  }
  MOCK_PERFORMANCE.push(data);
}

export async function getAssessmentCycles(): Promise<AssessmentCycle[]> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: read the `AssessmentCycles` tab from
    // GOOGLE_PORTAL_SHEET_ID.
  }
  return MOCK_CYCLES;
}

export async function getUserByEmail(email: string): Promise<User | undefined> {
  if (isLiveMode()) {
    // REAL INTEGRATION POINT: read the `Users` tab from GOOGLE_PORTAL_SHEET_ID.
  }
  return MOCK_USERS.find((u) => u.email.toLowerCase() === email.toLowerCase());
}

// Demo accounts — bcrypt hash of "demo1234" for all three, so the app is
// fully clickable out of the box. Replace with real Admin-provisioned
// accounts once GOOGLE_PORTAL_SHEET_ID is live (see spec Section 10).
// Password for all three demo accounts: demo1234
const DEMO_HASH = "$2a$10$.ziCaVO5o5H7bCcZtfiHFuO0r1ARK1.WNs/RIyRXqJJPknS0Ui7W6";
const MOCK_USERS: User[] = [
  { userId: "u1", role: "admin", email: "admin@tarlacct.demo", passwordHash: DEMO_HASH },
  { userId: "u2", role: "supervisor", email: "supervisor@tarlacct.demo", passwordHash: DEMO_HASH, districtIds: ["d8"] },
  { userId: "u3", role: "school", email: "school@tarlacct.demo", passwordHash: DEMO_HASH, schoolId: "s1" },
];

// ---------------------------------------------------------------------------
// REAL INTEGRATION POINT: uncomment and fill in once credentials exist.
// See spec Section 4 for the full service-account setup walkthrough.
// ---------------------------------------------------------------------------
//
// import { google } from "googleapis";
//
// export function getSheetsClient() {
//   const auth = new google.auth.JWT({
//     email: process.env.GOOGLE_SHEETS_CLIENT_EMAIL,
//     key: (process.env.GOOGLE_SHEETS_PRIVATE_KEY || "").replace(/\\n/g, "\n"),
//     scopes: [
//       "https://www.googleapis.com/auth/spreadsheets",
//       "https://www.googleapis.com/auth/drive",
//     ],
//   });
//   return google.sheets({ version: "v4", auth });
// }
